/**
 * Validador de Formulario
 */


function validar(){
	let nome = frmContato.nome.value
	let fone = frmContato.fone.value
	if (nome === ""){
		alert('preenceha o campo Nome')
		frmcontato.nome.focus()
		return false
	}else if( fone ===""){
		alert('preenceha o campo Fone')
		frmcontato.fone.focus()
		return false
	}else{
		document.forms["frmContato"].submit()
	}
		
	
}